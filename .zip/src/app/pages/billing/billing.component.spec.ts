import { async, ComponentFixture, TestBed ,TestModuleMetadata } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { BillingComponent } from './billing.component';

import { BillingFormModel } from 'src/app/model/billingformfields.model';

describe('BillingComponent', () => {
  let component: BillingComponent;
  let fixture: ComponentFixture<BillingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BillingComponent ],
      imports: [
        FormsModule, ReactiveFormsModule
      ],
      providers: [BillingFormModel]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BillingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });


  it('should create', () => {
    expect(component).toBeTruthy();
  });

  beforeEach(async(() => {
    fixture = TestBed.createComponent(BillingComponent);
    component = fixture.componentInstance;
    component.ngOnInit();
    component.cartflag = false;
    // fixture.detectChanges();
    // component.form.controls.first_name.setValue('xxx');
    // component.form.controls.last_name.setValue('xxxx');
    // component.form.controls.email.setValue('xxxx@xxx.de');
    // component.form.controls.message.setValue('xxx');
    // component.form.controls.company.setValue('xxx');
    // component.form.controls.phone.setValue('012');
    // component.form.controls.salutation.setValue('Frau');
    // component.form.controls.subject.setValue('xxx');
    // component
  }));
    // it('should call getDataFromWidget() on init method',()=>{
    //     spyOn(component,'getDataFromWidget').and.callThrough();
    //     component.ngOnInit();
    //     expect(component.getDataFromWidget).toHaveBeenCalled()
    // })

    
  
});